strings = ['Some string','Art','Music','Artificial Intelligence']
print ([x.lower() for x in strings if len(x) > 5])